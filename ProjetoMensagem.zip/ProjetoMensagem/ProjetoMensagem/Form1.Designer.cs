﻿namespace ProjetoMensagem
{
    partial class FrmEnvioMensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEnvioMensagem));
            this.btnMostrar = new System.Windows.Forms.Button();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.txtBooleano = new System.Windows.Forms.TextBox();
            this.lblBooleano = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMostrar
            // 
            this.btnMostrar.BackColor = System.Drawing.Color.Black;
            this.btnMostrar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnMostrar.Location = new System.Drawing.Point(36, 338);
            this.btnMostrar.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(114, 44);
            this.btnMostrar.TabIndex = 0;
            this.btnMostrar.Text = "MOSTRAR";
            this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblInteiro.Location = new System.Drawing.Point(31, 21);
            this.lblInteiro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(61, 25);
            this.lblInteiro.TabIndex = 1;
            this.lblInteiro.Text = "Inteiro";
            // 
            // txtInteiro
            // 
            this.txtInteiro.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtInteiro.Location = new System.Drawing.Point(36, 52);
            this.txtInteiro.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(249, 32);
            this.txtInteiro.TabIndex = 2;
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDecimal.Location = new System.Drawing.Point(31, 90);
            this.lblDecimal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(75, 25);
            this.lblDecimal.TabIndex = 3;
            this.lblDecimal.Text = "Decimal";
            // 
            // txtDecimal
            // 
            this.txtDecimal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtDecimal.Location = new System.Drawing.Point(36, 121);
            this.txtDecimal.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(249, 32);
            this.txtDecimal.TabIndex = 4;
            // 
            // txtTexto
            // 
            this.txtTexto.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTexto.Location = new System.Drawing.Point(36, 200);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(249, 32);
            this.txtTexto.TabIndex = 6;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTexto.Location = new System.Drawing.Point(31, 169);
            this.lblTexto.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(56, 25);
            this.lblTexto.TabIndex = 5;
            this.lblTexto.Text = "Texto";
            // 
            // txtBooleano
            // 
            this.txtBooleano.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtBooleano.Location = new System.Drawing.Point(36, 280);
            this.txtBooleano.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtBooleano.Name = "txtBooleano";
            this.txtBooleano.Size = new System.Drawing.Size(249, 32);
            this.txtBooleano.TabIndex = 8;
            // 
            // lblBooleano
            // 
            this.lblBooleano.AutoSize = true;
            this.lblBooleano.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblBooleano.Location = new System.Drawing.Point(31, 249);
            this.lblBooleano.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBooleano.Name = "lblBooleano";
            this.lblBooleano.Size = new System.Drawing.Size(87, 25);
            this.lblBooleano.TabIndex = 7;
            this.lblBooleano.Text = "Booleano";
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnLimpar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLimpar.Location = new System.Drawing.Point(160, 338);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(125, 44);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(173, 391);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(112, 28);
            this.btnSomar.TabIndex = 10;
            this.btnSomar.Text = "button1";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // FrmEnvioMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(336, 431);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtBooleano);
            this.Controls.Add(this.lblBooleano);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.btnMostrar);
            this.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "FrmEnvioMensagem";
            this.Text = "Envio de Mensagens";
            this.Load += new System.EventHandler(this.FrmEnvioMensagem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.TextBox txtBooleano;
        private System.Windows.Forms.Label lblBooleano;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSomar;
    }
}

