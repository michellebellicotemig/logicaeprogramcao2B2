﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class FrmEnvioMensagem : Form
    {
        public FrmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void FrmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Para programar o evento, cliquei duas vezes no fundo do formulário.");
            MessageBox.Show("O evento load ocorre quando o form abre. ");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Para programar o evento, cliquei duas vezes no botão mostrar.");

            //Como pegar dados na tela? 
            int valorInteiro = int.Parse(txtInteiro.Text);
            string valorTexto = txtTexto.Text;
            float valorDecimal = float.Parse(txtDecimal.Text);
            bool valorBooleano = bool.Parse(txtBooleano.Text);

            //Como mostrar na tela cada um dos dados? 
            MessageBox.Show("No txtTexto foi digitado = " + valorTexto);
            MessageBox.Show("No txtInteiro foi digitado = " + valorInteiro);
            MessageBox.Show("No txtDecimal foi digitado = " + valorDecimal);
            MessageBox.Show("No txtBooleano foi digitado = " + valorBooleano);
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão btnSomar " + btnSomar.Text);
        }
    }
}
