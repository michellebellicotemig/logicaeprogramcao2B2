﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Michelle_2B2
{
    public partial class FrmQuestao01 : Form
    {
        //Criar aqui; 
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Primeiro pegue os valores na tela 
            string nomeEmpresa = txtNomeEmpresa.Text;
            float valorKwh = float.Parse(txtValorKWh.Text);
            float qtdConsumida = float.Parse(txtQtdConsumida.Text);
            int diasAtraso = int.Parse(txtDiasAtraso.Text);
            float resultado;

            //Esse é o cálculo
            resultado = (valorKwh * qtdConsumida) + (valorKwh * qtdConsumida * 1.5f/100 * diasAtraso);

            //Resultado 
            lblResultado.Text = resultado.ToString("C");
        }
    }
}
