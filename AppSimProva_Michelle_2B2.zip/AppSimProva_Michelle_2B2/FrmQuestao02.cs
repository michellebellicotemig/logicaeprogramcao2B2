﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Michelle_2B2
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Primeiro pegar os valores da tela
            float valor1 = float.Parse(txtValor01.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);


            //Depois calcular e mostrar na tela
            lblResultado1.Text = (valor1 * 10 / 100 + valor1).ToString("C");
            lblResultado2.Text = (valor2 * 10 / 100 + valor2).ToString("C");
            lblResultado3.Text = (valor3 * 10 / 100 + valor3).ToString("C");
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            txtValor01.Clear();
            txtValor2.Clear();
            txtValor3.Clear();
            lblResultado1.Text = "-";
            lblResultado2.Text = "-";
            lblResultado3.Text = "-";
        }
    }
}
