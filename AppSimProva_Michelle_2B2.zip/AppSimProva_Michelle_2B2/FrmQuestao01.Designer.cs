﻿namespace AppSimProva_Michelle_2B2
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubTitulo = new System.Windows.Forms.Label();
            this.pnlCentro = new System.Windows.Forms.Panel();
            this.txtNomeEmpresa = new System.Windows.Forms.TextBox();
            this.lblNomeEmpresa = new System.Windows.Forms.Label();
            this.lblValorKWh = new System.Windows.Forms.Label();
            this.txtQtdConsumida = new System.Windows.Forms.TextBox();
            this.lblQtdConsumida = new System.Windows.Forms.Label();
            this.txtValorKWh = new System.Windows.Forms.TextBox();
            this.lblQtdDiasAtraso = new System.Windows.Forms.Label();
            this.txtDiasAtraso = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblTotalPagar = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlCentro.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(67)))), ((int)(((byte)(50)))));
            this.pnlTopo.Controls.Add(this.lblSubTitulo);
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Location = new System.Drawing.Point(-2, -3);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(650, 115);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTitulo.Location = new System.Drawing.Point(24, 22);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(242, 73);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "CEMIG";
            // 
            // lblSubTitulo
            // 
            this.lblSubTitulo.AutoSize = true;
            this.lblSubTitulo.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTitulo.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblSubTitulo.Location = new System.Drawing.Point(420, 81);
            this.lblSubTitulo.Name = "lblSubTitulo";
            this.lblSubTitulo.Size = new System.Drawing.Size(214, 25);
            this.lblSubTitulo.TabIndex = 1;
            this.lblSubTitulo.Text = "Conta da Energia Elétrica";
            // 
            // pnlCentro
            // 
            this.pnlCentro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(106)))), ((int)(((byte)(79)))));
            this.pnlCentro.Controls.Add(this.lblTotalPagar);
            this.pnlCentro.Controls.Add(this.lblResultado);
            this.pnlCentro.Controls.Add(this.btnCalcular);
            this.pnlCentro.Controls.Add(this.lblQtdDiasAtraso);
            this.pnlCentro.Controls.Add(this.txtDiasAtraso);
            this.pnlCentro.Controls.Add(this.lblQtdConsumida);
            this.pnlCentro.Controls.Add(this.txtValorKWh);
            this.pnlCentro.Controls.Add(this.lblValorKWh);
            this.pnlCentro.Controls.Add(this.txtQtdConsumida);
            this.pnlCentro.Controls.Add(this.lblNomeEmpresa);
            this.pnlCentro.Controls.Add(this.txtNomeEmpresa);
            this.pnlCentro.Location = new System.Drawing.Point(-2, 118);
            this.pnlCentro.Name = "pnlCentro";
            this.pnlCentro.Size = new System.Drawing.Size(650, 339);
            this.pnlCentro.TabIndex = 1;
            // 
            // txtNomeEmpresa
            // 
            this.txtNomeEmpresa.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeEmpresa.Location = new System.Drawing.Point(37, 64);
            this.txtNomeEmpresa.Name = "txtNomeEmpresa";
            this.txtNomeEmpresa.Size = new System.Drawing.Size(583, 32);
            this.txtNomeEmpresa.TabIndex = 0;
            // 
            // lblNomeEmpresa
            // 
            this.lblNomeEmpresa.AutoSize = true;
            this.lblNomeEmpresa.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeEmpresa.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNomeEmpresa.Location = new System.Drawing.Point(32, 36);
            this.lblNomeEmpresa.Name = "lblNomeEmpresa";
            this.lblNomeEmpresa.Size = new System.Drawing.Size(251, 25);
            this.lblNomeEmpresa.TabIndex = 1;
            this.lblNomeEmpresa.Text = "Nome da Empresa/Residência";
            // 
            // lblValorKWh
            // 
            this.lblValorKWh.AutoSize = true;
            this.lblValorKWh.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorKWh.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblValorKWh.Location = new System.Drawing.Point(32, 119);
            this.lblValorKWh.Name = "lblValorKWh";
            this.lblValorKWh.Size = new System.Drawing.Size(95, 25);
            this.lblValorKWh.TabIndex = 3;
            this.lblValorKWh.Text = "Valor KWh";
            // 
            // txtQtdConsumida
            // 
            this.txtQtdConsumida.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdConsumida.Location = new System.Drawing.Point(267, 147);
            this.txtQtdConsumida.Name = "txtQtdConsumida";
            this.txtQtdConsumida.Size = new System.Drawing.Size(184, 32);
            this.txtQtdConsumida.TabIndex = 2;
            // 
            // lblQtdConsumida
            // 
            this.lblQtdConsumida.AutoSize = true;
            this.lblQtdConsumida.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdConsumida.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblQtdConsumida.Location = new System.Drawing.Point(262, 119);
            this.lblQtdConsumida.Name = "lblQtdConsumida";
            this.lblQtdConsumida.Size = new System.Drawing.Size(198, 25);
            this.lblQtdConsumida.TabIndex = 5;
            this.lblQtdConsumida.Text = "Quantidade Consumida";
            // 
            // txtValorKWh
            // 
            this.txtValorKWh.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorKWh.Location = new System.Drawing.Point(37, 147);
            this.txtValorKWh.Name = "txtValorKWh";
            this.txtValorKWh.Size = new System.Drawing.Size(184, 32);
            this.txtValorKWh.TabIndex = 4;
            // 
            // lblQtdDiasAtraso
            // 
            this.lblQtdDiasAtraso.AutoSize = true;
            this.lblQtdDiasAtraso.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdDiasAtraso.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblQtdDiasAtraso.Location = new System.Drawing.Point(488, 119);
            this.lblQtdDiasAtraso.Name = "lblQtdDiasAtraso";
            this.lblQtdDiasAtraso.Size = new System.Drawing.Size(132, 25);
            this.lblQtdDiasAtraso.TabIndex = 7;
            this.lblQtdDiasAtraso.Text = "Dias em Atraso";
            // 
            // txtDiasAtraso
            // 
            this.txtDiasAtraso.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasAtraso.Location = new System.Drawing.Point(493, 147);
            this.txtDiasAtraso.Name = "txtDiasAtraso";
            this.txtDiasAtraso.Size = new System.Drawing.Size(127, 32);
            this.txtDiasAtraso.TabIndex = 6;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnCalcular.Location = new System.Drawing.Point(37, 257);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(583, 53);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.CausesValidation = false;
            this.lblResultado.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.Yellow;
            this.lblResultado.Location = new System.Drawing.Point(536, 215);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(18, 25);
            this.lblResultado.TabIndex = 9;
            this.lblResultado.Text = "-";
            // 
            // lblTotalPagar
            // 
            this.lblTotalPagar.AutoSize = true;
            this.lblTotalPagar.CausesValidation = false;
            this.lblTotalPagar.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPagar.ForeColor = System.Drawing.Color.Yellow;
            this.lblTotalPagar.Location = new System.Drawing.Point(388, 215);
            this.lblTotalPagar.Name = "lblTotalPagar";
            this.lblTotalPagar.Size = new System.Drawing.Size(119, 25);
            this.lblTotalPagar.TabIndex = 10;
            this.lblTotalPagar.Text = "Total a Pagar";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 450);
            this.Controls.Add(this.pnlCentro);
            this.Controls.Add(this.pnlTopo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "CEMIG - Conta Energia Elétrica";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlCentro.ResumeLayout(false);
            this.pnlCentro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblSubTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlCentro;
        private System.Windows.Forms.Label lblTotalPagar;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblQtdDiasAtraso;
        private System.Windows.Forms.TextBox txtDiasAtraso;
        private System.Windows.Forms.Label lblQtdConsumida;
        private System.Windows.Forms.TextBox txtValorKWh;
        private System.Windows.Forms.Label lblValorKWh;
        private System.Windows.Forms.TextBox txtQtdConsumida;
        private System.Windows.Forms.Label lblNomeEmpresa;
        private System.Windows.Forms.TextBox txtNomeEmpresa;
    }
}

